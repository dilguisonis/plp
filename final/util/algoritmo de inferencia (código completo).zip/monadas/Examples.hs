module Examples(expr)
where

import ParserLC
import PrettyPrintLC
import TypeInferenceMonad

expr :: Int -> String
-- Ejemplos con Var, Zero, Succ y App
expr 1 = "x"
expr 2 = "0"
expr 3 = "succ(x)"
expr 4 = "succ(0)"
expr 5 = "f x"
expr 6 = "f 0"
expr 7 = "succ(f 0)"
expr 8 = "0 f"
expr 9 = "f 0 succ(succ(0))"
expr 10 = "f (0 succ(succ(0)))"
expr 11 = "f x y z"
expr 12 = "f (x y z)"
expr 13 = "f succ(x) y z"
expr 14 = "f (succ(x) y z)"
expr 15 = "x x"
expr 16 = "(\\x -> x)"
expr 17 = "(\\x -> 0)"
expr 18 = "(\\y -> x)"
expr 19 = "(\\x -> x) y"
expr 20 = "\\s -> \\x -> \\y -> s x y"
expr 21 = "\\s -> \\x -> \\y -> s (x y)"
expr 22 = "(\\s -> \\x -> \\y -> s) (x y)"
-- Ejemplos con todos los constructores
expr 23 = "\\x -> \\y -> if x then y x else pred(succ(0))"
expr 24 = "if true then 0 else succ(0)"
expr 25 = "if true then x else 0"
expr 26 = "if x then x else 0"
expr 27 = "if x then y else 0"
expr 28 = "if x then y else z"
expr 29 = "if x then y else succ(y)"
expr 30 = "if true then succ(x y) else x (succ(y))"
expr 31 = "if true then x succ(succ(0)) else x true"
expr 32 = "(\\f -> if true then f 0 else f false) (\\x -> 0)"
expr 33 = "(if true then (\\x -> x) 0 else (\\x -> x) false)"
expr 34 = "(if true then (\\x -> 0) 0 else (\\x -> 0) false)"
expr 35 = "\\s -> \\x -> \\y -> if isZero(x) then y else succ(s pred(x) y)"
expr n = error $ "La expresión " ++ show n ++ " no está definida."
