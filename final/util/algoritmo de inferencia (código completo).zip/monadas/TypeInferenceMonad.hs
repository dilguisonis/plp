module TypeInferenceMonad (TypingJudgment, Result(..), inferType)

where

import Data.List(intersect)
import Exp
import Type
import Unification

------------
-- Errors --
------------

data Result a = OK a | Error String

spreadError :: Result a -> (a -> Result b) -> Result b
spreadError (OK a) f = f a
spreadError (Error s) _ = Error s

returnE :: a -> Result a
returnE = OK

failE :: String -> Result a
failE = Error

------------------
-- Typing State --
------------------

data TypingState a = TS (Int->Result (Int, a))

applyTS :: TypingState a -> Int -> Result (Int, a)
applyTS (TS f) = f

instance Monad TypingState where
  return a = TS (\n -> returnE (n, a))
  (>>=) = spreadTypingState

instance Applicative TypingState where
    pure = returnTS
    (<*>) tsf tsa = TS (\n->spreadError (applyTS tsa n) (\(n', a) -> spreadError (applyTS tsf n) (\(n', f) -> returnE (n', f a))))

instance Functor TypingState where
    fmap f tsa = TS (\n->spreadError (applyTS tsa n) (\(n', a) -> returnE (n', (f a))))

spreadTypingState :: TypingState a -> (a -> TypingState b) -> TypingState b
spreadTypingState tsa f = TS (\n->spreadError (applyTS tsa n) (\(n', a) -> applyTS (f a) n'))

returnTS :: a -> TypingState a
returnTS a = TS (\n -> returnE (n, a))

errorTS :: String -> TypingState a
errorTS s = TS (const $ failE s)

freshTS :: TypingState Type
freshTS = TS (\n -> returnE (n+1, TVar n))

unifTS :: [UnifGoal] -> TypingState Subst
unifTS types = case mgu types of
                  UOK subst -> returnTS subst
                  UError u1 u2 -> uErrorTS u1 u2

uErrorTS :: Type -> Type -> TypingState a
uErrorTS t1 t2 = TS (const $ uError t1 t2)

--------------------
-- Type Inference --
--------------------

type TypingJudgment = (Context, AnnotExp, Type)

inferType :: PlainExp -> Result TypingJudgment
inferType e = case applyTS (infer' e) 0 of
    OK (_, tj) -> OK tj
    Error s -> Error s

infer' :: PlainExp -> TypingState TypingJudgment
infer' (VarExp x)     = do
                          freshT <- freshTS
                          return (extendC emptyContext x freshT, VarExp x, freshT)
infer' ZeroExp        = return (emptyContext, ZeroExp, TNat)
infer' (SuccExp e)    = do
                          (gamma', e', t') <- infer' e
                          subst <- unifTS [(t', TNat)]
                          return (subst <.> gamma',
                                       subst <.> SuccExp e',
                                        TNat)
infer' (PredExp e)    = do
                          (gamma', e', t') <- infer' e 
                          subst <- unifTS [(t', TNat)] 
                          return (subst <.> gamma',
                                       subst <.> PredExp e',
                                        TNat)
infer' (IsZeroExp e)  = do
                          (gamma', e', t') <- infer' e
                          subst <- unifTS [(t', TNat)]
                          return (subst <.> gamma',
                                       subst <.> IsZeroExp e',
                                        TBool)
infer' TrueExp        = return (emptyContext, TrueExp, TBool)
infer' FalseExp       = return (emptyContext, FalseExp, TBool)
infer' (IfExp u v w)  = do
                        (gamma1, u', t1) <- infer' u
                        (gamma2, v', t2) <- infer' v
                        (gamma3, w', t3) <- infer' w
                        s <- let goals = (t1, TBool)
                                              :(t2, t3)
                                                 :(getGoals gamma1 gamma2)++(getGoals gamma1 gamma3)++(getGoals gamma2 gamma3)
                                in unifTS goals
                        return (joinC $ map (s <.>) [gamma1, gamma2, gamma3],
                                            s <.> IfExp u' v' w',
                                              s <.> t2)
infer' (LamExp x _ e) = do
                         (gamma', e', t) <- infer' e
                         tx <- evalOrFresh gamma' x
                         return (removeC gamma' x, LamExp x tx e', TFun tx t)
infer' (AppExp u v)   = do
                         (gamma1, u', t1) <- infer' u
                         (gamma2, v', t2) <- infer' v
                         freshT <- freshTS
                         s <- let goals = getGoals gamma1 gamma2
                              in (unifTS $ (t1, TFun t2 freshT) : goals)
                         return (joinC $ map (s <.>) [gamma1, gamma2],
                                             s <.> AppExp u' v',
                                              s <.> freshT)

getGoals :: Context -> Context -> [UnifGoal]
getGoals gamma1 gamma2 = [(evalC gamma1 x, evalC gamma2 x) |
                        x <- intersect (domainC gamma1) (domainC gamma2)]

uError :: Type -> Type -> Result a
uError t1 t2 = Error $ "Cannot unify " ++ show t1 ++ " and " ++ show t2

evalOrFresh :: Context -> Symbol -> TypingState Type
evalOrFresh gamma x | x `elem` (domainC gamma) = returnTS $ evalC gamma x
                  | otherwise = freshTS

removeAllC :: Context -> [Symbol] -> Context
removeAllC gamma = foldr (flip removeC) gamma
