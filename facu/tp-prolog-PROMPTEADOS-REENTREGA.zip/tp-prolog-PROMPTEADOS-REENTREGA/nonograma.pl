
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	En el presente documento .pl hemos empleado las sugerencias sobre usar
%	la unificación nativa de prolog cuando era posible, evitar el uso de =, =:= e "is"
%	innecesarios. También hemos hecho el ej 5 y el 7 en una sola linea (tal y como sugirió
% 	el Corrector). Además, repensamos de forma más simple al caso base del ej 4. 
%	
%	· 	Sacamos el cut innecesario del ejercio 3, no hacia falta.
%	· 	En el ej 0 había una linea duplicada, la eliminamos.
%	· 	En el ej 10 habia un "is" que estaba de más. 
%	· 	Cuando cambiamos por unificación nativa, pusimos " %reemplazado con unificación nativa"
%
%	La tabla sigue siendo la misma que antes y la justificación de no reversibilidad se 
%	mantiene igual ya que solamente cambiamos la forma en la que unifica. 
%
%	Esperamos que esta reentrega cumpla con las expectativas. 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 1

%construyo la fila de C columnas.
fila(0,[]).
fila(C,[_|R]):- C>0, N is (C-1),fila(N,R). %reemplazado con unificación nativa
%matriz construye F filas.
matriz(0,_,[]).
matriz(F, C, [R|M0]) :-F >0,  N is (F-1),fila(C,R), matriz(N,C,M0). %reemplazado con unificación nativa

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 2

%agregamos E a la recursion.
replicar(_,0,[]).
replicar(E,N,[E|R]):-N>0,M is(N-1),replicar(E,M,R). %reemplazado con unificación nativa


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 3

%Sabemos que la primera fila de la matriz transpuesta se forma con
%las cabezas de las filas de la matriz y entonces, el resto de la
%matriz transpuesta será transponiendo las colas de todas las filas.
%primero separamos en cabezas y colas:
separarCabezasColas([],[],[]).
separarCabezasColas([[L|Ls]|M],[L|Rh],[Ls|Rt]):-separarCabezasColas(M,Rh,Rt). %reemplazado con unificación nativa

%separamos todas las cabezas de las filas, transponemos las colas y
%ligamos los resultados de la recursion.
transponer([[]|_],[]). %sacamos el cut innecesario
transponer([M|Ms],[Hs|MTs]):-separarCabezasColas([M|Ms],Hs,Ts),transponer(Ts,MTs). %reemplazado con unificación nativa

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Predicado dado armarNono/3
armarNono(RF, RC, nono(M, RS)) :-
	length(RF, F),
	length(RC, C),
	matriz(F, C, M),
	transponer(M, Mt),
	zipR(RF, M, RSFilas),
	zipR(RC, Mt, RSColumnas),
	append(RSFilas, RSColumnas, RS).

zipR([], [], []).
zipR([R|RT], [L|LT], [r(R,L)|T]) :- zipR(RT, LT, T).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 4
%Tenemos k restricciones, por lo tanto la minima cantidad de celdas no pintadas (o en blanco)
% es B_min = k-1.
%La cantidad de celdas blancas que dispongo para distribuir es B_d = CantDeCeldas - CantCeldasNegras - B_min.
%La lista final será [b_0,r_1,b_1,...,r_k,b_k] por lo que tengo B_d celdas en blanco para distribuir en
%k+1 lugares.
%La cantidad de pintadas validas es encontrar todas las combinaciones de numeros que sumados entre sí den B_d.
%Es decir: x_0+x_1+..+x_k=B_d donde x_0,x_k >= 0 y x_i >=1, 1<=i<=k-1.

%a partir de dame_config obtengo todas las posibles configuraciones de las celdas en blanco. Es decir,
%tenemos el arreglo b_0,_b_1,...,b_k ya que b_0 contiene x_0 celdas en blanco, b_1 contiene x_1 + 1 celdas en blanco
%(ya que esta de base el separador por regla de restriccion), ...,b_k contiene x_k celdas en blanco.
%por lo tanto queda construir la fila de pintadas validas.
% caso K = 0 unificación nativa
pintadasValidas(r([], Celdas)) :-
		maplist(=(o), Celdas). %podriamos haber usado replicar pero ya lo habiamos hecho de esta manera
		%y es nuestra manera de reflejar que aprendimos algo de la correción.

% unificación nativa
pintadasValidas(r([R|Rs], Celdas)) :-
		sum_list([R|Rs], CantCeldasNegras),
		length(Celdas, SizeFila),
		length([R|Rs], K),
		B_min is (K-1),
		B_d is (SizeFila-CantCeldasNegras-B_min),
		EspaciosLibres is (K+1),
		dame_config(B_d,EspaciosLibres,ConfigBlancas),
		construirPintada([R|Rs],ConfigBlancas,Celdas).%teniendo las posibles configs de las celdas blancas y como deben disponerse
								%las celdas negras, construimos la fila [b_0,r_1,..,r_k,b_k]

%defino predicado dame_config que toma un natural E, otro natural Size y una lista
%que será verdadero si la suma de los elementos de la lista de tamaño Size es igual a E.
dame_config(0,0,[]).
dame_config(E, Size, [L|Ls]):-
    Size > 0,
    between(0, E, L),
    N is (E - L),
    M is (Size - 1),
    dame_config(N, M, Ls).
		
construirPintada([],[B_k],Fila):- replicar(o,B_k,Fila). %caso base, no quedan restricciones, queda b_k cantidad final de 'o's.
construirPintada([R|Res],[B|Bs],Fila):-
		replicar(o,B,B_i),
		replicar(x,R,R_i),
		separador(Res,Separador),%si quedan elementos en Res, agrego 'o'.
		construirPintada(Res,Bs,L),
		append(B_i,R_i,Temp1),
		append(Temp1,Separador,Temp2),
		append(Temp2,L,Fila).

separador([],[]).
separador([_|_],[o]). 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 5
%sabemos que el motor de prolog funciona con backtracking. Por lo tanto la función, coloquialmente hablando,
%es "El nonograma NN es un nonograma válido si cada fila es una pintada válida."
% Era mucho más facil, todas las filas deben ser pintadas validas. La complicamos mucho antes. 
resolverNaive(nono(_, RS)) :-
    maplist(pintadasValidas, RS).
%nn(0, NN), resolverNaive(NN), mostrarNono(NN).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 6
%Lo que se pide es, ver todas las soluciones posibles (pintadasValidas) y pintar aquellas celdas en la que en todas las soluciones 
%está el mismo valor ('x' o 'o').
%Es decir, dada la matriz con todas las pintadas validas, si todos los elementos de una columna contiene el mismo elemento, entonces
%la posicion de la Fila correspondiente a la de la columna sera ese elemento.
pintarObligatorias(r(Res,Celdas)) :- 
	findall(Celdas, pintadasValidas(r(Res,Celdas)),Msol),
	transponer(Msol,MsolTranspuesta),%transponemos para tener las columnas como filas y asi recursionar en la columna (ahora fila).
	construirFila(MsolTranspuesta,Celdas).


construirFila([],[]).
construirFila([M|Mt],[x|Ls]):-%caso 'x'.
	todos_iguales(x,M),
	!,	
	construirFila(Mt,Ls).
construirFila([M|Mt],[o|Ls]):-%caso 'o'.
	todos_iguales(o,M),
	!,	
	construirFila(Mt,Ls).
construirFila([_|Mt],[L|Ls]):-%caso libre.
	var(L),	
	construirFila(Mt,Ls).

todos_iguales(_,[]).
todos_iguales(E,[E|Ls]):- todos_iguales(E,Ls).

% Predicado dado combinarCelda/3
combinarCelda(A, B, _) :- var(A), var(B).
combinarCelda(A, B, _) :- nonvar(A), var(B).
combinarCelda(A, B, _) :- var(A), nonvar(B).
combinarCelda(A, B, A) :- nonvar(A), nonvar(B), A = B.
combinarCelda(A, B, _) :- nonvar(A), nonvar(B), A \== B.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 7

% Lo mismo que el 5. 

deducir1Pasada(nono(_, RS)) :-
    maplist(pintarObligatorias, RS).


% Predicado dado
cantidadVariablesLibres(T, N) :- term_variables(T, LV), length(LV, N).

% Predicado dado
deducirVariasPasadas(NN) :-
	NN = nono(M,_),
	cantidadVariablesLibres(M, VI), % VI = cantidad de celdas sin instanciar en M en este punto
	deducir1Pasada(NN),
	cantidadVariablesLibres(M, VF), % VF = cantidad de celdas sin instanciar en M en este punto
	deducirVariasPasadasCont(NN, VI, VF).

% Predicado dado
deducirVariasPasadasCont(_, A, A). % Si VI = VF entonces no hubo más cambios y frenamos.
deducirVariasPasadasCont(NN, A, B) :- A =\= B, deducirVariasPasadas(NN).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 8

restriccionConMenosLibres(nono(_,RS), r(Res, Celdas)):- %reemplazado con unificación nativa
			member(r(Res, Celdas),RS),%agarramos una restriccion candidata a menos libres
			cantidadVariablesLibres(Celdas,N),%vemos cuantas libres hay en esa fila
			N>0,%al menos una no instanciada.
			not(
				(member(r(_, Celdas2),RS), %reemplazado con unificación nativa
				cantidadVariablesLibres(Celdas2,N2),
				N2>0,
				N2<N)
			). %no existe una restricción que tenga menos variables libres.
			

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%		
% Ejercicio 9
resolverDeduciendo(nono(M,RS)) :- %reemplazado con unificación nativa
		deducirVariasPasadas(nono(M,RS)),
		cantidadVariablesLibres(M,0),%vemos si quedo alguna variable libre en el nono
		!.
resolverDeduciendo(nono(M,RS)):- %reemplazado con unificación nativa
		deducirVariasPasadas(nono(M,RS)),
		cantidadVariablesLibres(M,X),%vemos cuantas variables libres quedan.
		X>0,%por seguridad
		restriccionConMenosLibres(nono(M,RS), r(Res,Celdas)), %reemplazado con unificación nativa
		!,%Nos quedamos con la primer restriccion que tenga la menor cantidad de libres para evitar duplicados.
		pintadasValidas(r(Res,Celdas)),
		deducirVariasPasadas(nono(M,RS)), %seguimos deduciendo habiendo instanciado con nuevas pintadas.
		resolverDeduciendo(nono(M,RS)). %vemos si ya está resuelto o si hay que seguir deduciendo.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 10

solucionUnica(nono(M,RS)) :- %reemplazado con unificación nativa
		findall(M,resolverDeduciendo(nono(M,RS)),ListaSoluciones),
		length(ListaSoluciones, 1). % remplazamos y lo optimizamos


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 11

tam(N, (F, C)) :-
    nn(N, nono([Fila|RestoFilas], _ )), %reemplazado con unificación nativa
    length([Fila|RestoFilas], F), % agarramos a F es la cantidad de filas
    length(Fila, C). % C es cantidad de columnas de la primera fila

solucionUnicaNn(N) :- nn(N, NN), solucionUnica(NN). % los nonos (NN) con sol unica..

esDeducible(N) :-
    nn(N, nono(M, RS)), %reemplazado con unificación nativa
    deducirVariasPasadas(nono(M, RS)), % vemos si se puede dedudcir con pasadas
    cantidadVariablesLibres(M, 0). % quedo resuelto? 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejercicio 12

% Cambiamos ligeramente a replicar/3, pero el analisis sigue siendo el mismo ya que
% lo problematico es en N>0.  
% replicar(_,0,[]).
% replicar(E,N,[E|R]):-N>0,M is(N-1),replicar(E,M,R). %reemplazado con unificación nativa

% cuando no definimos a N, entra al caso base sin problema.
% pero en el siguiente paso, N > 0 pide que N esté instaciado. Sino, tira error. 

% Ejemplo:
% 41 ?- 1 > 0.
% true.
% 42 ?- 2 > 0.
% true.
% 43 ?- N > 0.
% ERROR: Arguments are not sufficiently instantiated
% ERROR: In:
% ERROR:   [10] _15292>0
% ERROR:    [9] toplevel_call(user:user: ...) at /usr/lib/swi-prolog/boot/toplevel.pl:1173
% 44 ?- 

% entonces, no es reversible en el segundo argumento. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              %
%    Ejemplos de nonogramas    %
%        NO MODIFICAR          %
%    pero se pueden agregar    %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Fáciles
nn(0, NN) :- armarNono([[1],[2]],[[],[2],[1]], NN).
nn(1, NN) :- armarNono([[4],[2,1],[2,1],[1,1],[1]],[[4],[3],[1],[2],[3]], NN).
nn(2, NN) :- armarNono([[4],[3,1],[1,1],[1],[1,1]],[[4],[2],[2],[1],[3,1]], NN).
nn(3, NN) :- armarNono([[2,1],[4],[3,1],[3],[3,3],[2,1],[2,1],[4],[4,4],[4,2]], [[1,2,1],[1,1,2,2],[2,3],[1,3,3],[1,1,1,1],[2,1,1],[1,1,2],[2,1,1,2],[1,1,1],[1]], NN).
nn(4, NN) :- armarNono([[1, 1], [5], [5], [3], [1]], [[2], [4], [4], [4], [2]], NN).
nn(5, NN) :- armarNono([[], [1, 1], [], [1, 1], [3]], [[1], [1, 1], [1], [1, 1], [1]], NN).
nn(6, NN) :- armarNono([[5], [1], [1], [1], [5]], [[1, 1], [2, 2], [1, 1, 1], [1, 1], [1, 1]], NN).
nn(7, NN) :- armarNono([[1, 1], [4], [1, 3, 1], [5, 1], [3, 2], [4, 2], [5, 1], [6, 1], [2, 3, 2], [2, 6]], [[2, 1], [1, 2, 3], [9], [7, 1], [4, 5], [5], [4], [2, 1], [1, 2, 2], [4]], NN).
nn(8, NN) :- armarNono([[5], [1, 1], [1, 1, 1], [5], [7], [8, 1], [1, 8], [1, 7], [2, 5], [7]], [[4], [2, 2, 2], [1, 4, 1], [1, 5, 1], [1, 8], [1, 7], [1, 7], [2, 6], [3], [3]], NN).
nn(9, NN) :- armarNono([[4], [1, 3], [2, 2], [1, 1, 1], [3]], [[3], [1, 1, 1], [2, 2], [3, 1], [4]], NN).
nn(10, NN) :- armarNono([[1], [1], [1], [1, 1], [1, 1]], [[1, 1], [1, 1], [1], [1], [ 1]], NN).
nn(11, NN) :- armarNono([[1, 1, 1, 1], [3, 3], [1, 1], [1, 1, 1, 1], [8], [6], [10], [6], [2, 4, 2], [1, 1]], [[2, 1, 2], [4, 1, 1], [2, 4], [6], [5], [5], [6], [2, 4], [4, 1, 1], [2, 1, 2]], NN).
nn(12, NN) :- armarNono([[9], [1, 1, 1, 1], [10], [2, 1, 1], [1, 1, 1, 1], [1, 10], [1, 1, 1], [1, 1, 1], [1, 1, 1, 1, 1], [1, 9], [1, 2, 1, 1, 2], [2, 1, 1, 1, 1], [2, 1, 3, 1], [3, 1], [10]], [[], [9], [2, 2], [3, 1, 2], [1, 2, 1, 2], [3, 11], [1, 1, 1, 2, 1], [1, 1, 1, 1, 1, 1], [3, 1, 3, 1, 1], [1, 1, 1, 1, 1, 1], [1, 1, 1, 3, 1, 1], [3, 1, 1, 1, 1], [1, 1, 2, 1], [11], []], NN).
nn(13, NN) :- armarNono([[2], [1,1], [1,1], [1,1], [1], [], [2], [1,1], [1,1], [1,1], [1]], [[1], [1,3], [3,1,1], [1,1,3], [3]], NN).
nn(14, NN) :- armarNono([[1,1], [1,1], [1,1], [2]], [[2], [1,1], [1,1], [1,1]], NN).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              %
%    Predicados auxiliares     %
%        NO MODIFICAR          %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%! completar(+S)
%
% Indica que se debe completar el predicado. Siempre falla.
completar(S) :- write("COMPLETAR: "), write(S), nl, fail.

%! mostrarNono(+NN)
%
% Muestra una estructura nono(...) en pantalla
% Las celdas x (pintadas) se muestran como ██.
% Las o (no pintasdas) se muestran como ░░.
% Las no instanciadas se muestran como ¿?.
mostrarNono(nono(M,_)) :- mostrarMatriz(M).

%! mostrarMatriz(+M)
%
% Muestra una matriz. Solo funciona si las celdas
% son valores x, o, o no instanciados.
mostrarMatriz(M) :-
	M = [F|_], length(F, Cols),
	mostrarBorde('╔',Cols,'╗'),
	maplist(mostrarFila, M),
	mostrarBorde('╚',Cols,'╝').

mostrarBorde(I,N,F) :-
	write(I),
	stringRepeat('══', N, S),
	write(S),
	write(F),
	nl.

stringRepeat(_, 0, '').
stringRepeat(Str, N, R) :- N > 0, Nm1 is N - 1, stringRepeat(Str, Nm1, Rm1), string_concat(Str, Rm1, R).

%! mostrarFila(+M)
%
% Muestra una lista (fila o columna). Solo funciona si las celdas
% son valores x, o, o no instanciados.
mostrarFila(Fila) :-
	write('║'),
	maplist(mostrarCelda, Fila),
	write('║'),
	nl.

mostrarCelda(C) :- nonvar(C), C = x, write('██').
mostrarCelda(C) :- nonvar(C), C = o, write('░░').
mostrarCelda(C) :- var(C), write('¿?').
